#include "types.h"
#include "riscv.h"
#include "defs.h"
#include "param.h"
#include "memlayout.h"
#include "spinlock.h"
#include "proc.h"

uint64
sys_exit(void)
{
  int n;
  argint(0, &n);
  exit(n);
  return 0;  // not reached
}

uint64
sys_getpid(void)
{
  return myproc()->pid;
}

uint64
sys_fork(void)
{
  return fork();
}

uint64
sys_wait(void)
{
  uint64 p;
  argaddr(0, &p);
  return wait(p);
}

uint64
sys_waitx(void)
{
  uint64 addr, addr1, addr2;
  uint wtime, rtime;
  argaddr(0, &addr);
  argaddr(1, &addr1); // user virtual memory
  argaddr(2, &addr2);
  int ret = waitx(addr, &wtime, &rtime);
  struct proc* p = myproc();
  if (copyout(p->pagetable, addr1,(char*)&wtime, sizeof(int)) < 0)
    return -1;
  if (copyout(p->pagetable, addr2,(char*)&rtime, sizeof(int)) < 0)
    return -1;
  return ret;
}
uint64
sys_sbrk(void)
{
  uint64 addr;
  int n;

  argint(0, &n);
  addr = myproc()->sz;
  if(growproc(n) < 0)
    return -1;
  return addr;
}

uint64
sys_sleep(void)
{
  int n;
  uint ticks0;

  argint(0, &n);
  acquire(&tickslock);
  ticks0 = ticks;
  while(ticks - ticks0 < n){
    if(killed(myproc())){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
  }
  release(&tickslock);
  return 0;
}

uint64
sys_kill(void)
{
  int pid;

  argint(0, &pid);
  return kill(pid);
}

// return how many clock tick interrupts have occurred
// since start.
uint64
sys_uptime(void)
{
  uint xticks;

  acquire(&tickslock);
  xticks = ticks;
  release(&tickslock);
  return xticks;
}

uint64
sys_trace(void)
{
  int t;
  argint(0, &t);
  myproc()->mask_ = t;
  return 0;
}

uint64
sys_sigalarm(void)
{
  uint64 h;
  int t;
  argint(0, &t);
  argaddr(1, &h);
  if(t<0)
    return -1;
  if(h<0)
    return -1;
  myproc()->ticks_ = t;
  myproc()->handler_ = h;
  return 0;
}
uint64
sys_sigreturn(void)
{
  memmove(myproc()->trapframe, myproc()->alarm_trap_f, PGSIZE);
  kfree(myproc()->alarm_trap_f);
  myproc()->alarm_on = 0;
  myproc()->alarm_trap_f = 0;
  myproc()->current_ticks = 0;
  return myproc()->trapframe->a0;
}
uint64
sys_set_priority(void)
{
#ifndef PBS
  return -1;
#endif
  int priority, pid;
  int old = -1;
  argint(0, &priority);
  argint(1, &pid);
  set_priority(priority, pid, &old);
  return old;
}

int sys_settickets(void)
{
  int number_of_tickets;
  // Error
  argint(0, &number_of_tickets);
  if(number_of_tickets <= 0)  
    return -1;

  // acquire(&ptable.lock);
   set_proc_tckts(number_of_tickets);
  // release(&ptable.lock);

  return 0;
}
/* End of code added */


/* The following code is added by haoda le and netid hxl180046
system call, getpinfo
*/
// int sys_get_pinfo(void)
// {
//   struct pstat* target;
//   argptr(0,(void*)&target,sizeof(*target));

//   if(target == NULL)
//     return -1;

//   acquire(&ptable.lock);
//   struct proc* p;
//   for(p=ptable.proc;p != &(ptable.proc[NPROC]); p++)
//     {
//       const int index = p - ptable.proc;
//       if(p->state != UNUSED)
//         {
// 	  target->pid[index] = p->pid;
// 	  target->ticks[index] = p->ticks;
// 	  target->tickets[index] = p->tickets;
// 	  target->inuse[index] = p->inuse;
//         }
//     }
//   release(&ptable.lock);
//   return 0;
// }
// /* End of code added */


